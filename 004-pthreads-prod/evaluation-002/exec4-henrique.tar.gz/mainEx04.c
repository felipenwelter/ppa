#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "toolsv3.h"
#include "matrizv3.h"
#include "matriz-operacoesv3.h"
#include "matriz-operacoes-threads.h"

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
int main(int argc, char *argv[]) {

	// %%%%%%%%%%%%%%%%%%%%%%%% BEGIN %%%%%%%%%%%%%%%%%%%%%%%%
	// DECLARAÇÃO de VARIÁVEIS
	mymatriz mat_a, mat_b;
	mymatriz **mmultbloco, **mmult, **mmultthread, **mmultblocothread;
	matriz_bloco_t **Vsubmat_a, **Vsubmat_b, **Vsubmat_c;
	char filename[100];
	FILE *fmat;
	int nr_line;
	int *vet_line = NULL;
	int N, M, La, Lb, EXECUTIONS=10;
	double start_time, end_time;
	double recorded_time[4] = {0, 0, 0, 0};

  int nro_submatrizes=2,tasks=2;

	// %%%%%%%%%%%%%%%%%%%%%%%% END %%%%%%%%%%%%%%%%%%%%%%%%

	if (argc != 3 && argc != 4){
		printf ("ERRO: Numero de parametros %s <matriz_a> <matriz_b> [N threads]\n", argv[0]);
		exit (1);
	}

	if(argc == 4) {
		tasks = atoi(argv[3]);
		if(tasks < 1) {
			tasks = 2;
		}
	}

	// %%%%%%%%%%%%%%%%%%%%%%%% BEGIN %%%%%%%%%%%%%%%%%%%%%%%%
	//                Leitura da Matriz A (arquivo)
	fmat = fopen(argv[1],"r");
	if (fmat == NULL) {
		printf("Error: Na abertura dos arquivos.");
		exit(1);
	}
	extrai_parametros_matriz(fmat, &N, &La, &vet_line, &nr_line);
	//return 1;
	mat_a.matriz = NULL;
	mat_a.lin = N;
	mat_a.col = La;
	if (!malocar(&mat_a)) {
		printf ("ERROR: Out of memory\n");
	}
	filein_matriz (mat_a.matriz, N, La, fmat, vet_line, nr_line);
	free (vet_line);
	fclose(fmat);
	// %%%%%%%%%%%%%%%%%%%%%%%% END %%%%%%%%%%%%%%%%%%%%%%%%

	// %%%%%%%%%%%%%%%%%%%%%%%% BEGIN %%%%%%%%%%%%%%%%%%%%%%%%
	//               Leitura da Matriz B (arquivo)
	fmat = fopen(argv[2],"r");
	if (fmat == NULL) {
		printf("Error: Na abertura dos arquivos.");
		exit(1);
	}
	extrai_parametros_matriz(fmat, &Lb, &M, &vet_line, &nr_line);
	mat_b.matriz = NULL;
	mat_b.lin = Lb;
	mat_b.col = M;
	if (!malocar(&mat_b)) {
		printf ("ERROR: Out of memory\n");
	}
	filein_matriz (mat_b.matriz, Lb, M, fmat, vet_line, nr_line);
	free (vet_line);
	fclose(fmat);
	// %%%%%%%%%%%%%%%%%%%%%%%% END %%%%%%%%%%%%%%%%%%%%%%%%

	printf("\n%%%%%%%%%%%%%%%%\n");

	// %%%%%%%%%%%%%%%%%%%%%%%% BEGIN %%%%%%%%%%%%%%%%%%%%%%%%
	//            Operação de Multiplicação Sequencial
	mmult = (mymatriz **) malloc (sizeof(mymatriz *));
	printf("\n ##### Multiplicação Sequencial de Matrizes #####\n");

	for(int i = 0; i < EXECUTIONS; i++) {

		start_time = wtime();
		mmult[0] = mmultiplicar(&mat_a, &mat_b, 3);
		end_time = wtime();

		printf("\tRuntime: %f\n", end_time - start_time);
		recorded_time[0] += end_time - start_time;

	}

	recorded_time[0] = recorded_time[0] / EXECUTIONS;

	sprintf(filename, "mult_seq.result");
	fmat = fopen(filename,"w");
	fileout_matriz(mmult[0], fmat);
	fclose(fmat);
	// %%%%%%%%%%%%%%%%%%%%%%%% END %%%%%%%%%%%%%%%%%%%%%%%%

	// %%%%%%%%%%%%%%%%%%%%%%%% BEGIN %%%%%%%%%%%%%%%%%%%%%%%%
	//           Operações de Multiplicação em Bloco
	mmultbloco = (mymatriz **) malloc (sizeof(mymatriz *));
	printf("\n ##### Multiplicação em Bloco de Matrizes #####\n");

	for(int i = 0; i < EXECUTIONS; i++) {

		start_time = wtime();

		Vsubmat_a = particionar_matriz (mat_a.matriz, N, La, 1, 2);
		Vsubmat_b = particionar_matriz (mat_b.matriz, Lb, M, 0, 2);
		Vsubmat_c = csubmatrizv2 (N, M, nro_submatrizes);

		mmsubmatriz (Vsubmat_a[0], Vsubmat_b[0], Vsubmat_c[0]);
		mmsubmatriz (Vsubmat_a[1], Vsubmat_b[1], Vsubmat_c[1]);

		mmultbloco[0] = msomar(Vsubmat_c[0]->matriz, Vsubmat_c[1]->matriz, 1);

		end_time = wtime();
		//mimprimir(mmultbloco[0]);
		printf("\tRuntime: %f\n", end_time - start_time);
		recorded_time[1] += end_time - start_time;

	}

	recorded_time[1] = recorded_time[1] / EXECUTIONS;

	sprintf(filename, "mult_em_bloco.result");
	fmat = fopen(filename,"w");
	fileout_matriz(mmultbloco[0], fmat);
	fclose(fmat);
	// %%%%%%%%%%%%%%%%%%%%%%%% END %%%%%%%%%%%%%%%%%%%%%%%%

	// %%%%%%%%%%%%%%%%%%%%%%%% BEGIN %%%%%%%%%%%%%%%%%%%%%%%%
	//           Operação de Multiplicação Multi-thread
	mmultthread = (mymatriz **) malloc (sizeof(mymatriz *));
	printf("\n ##### Multiplicação Multi-thread de Matrizes #####\n");
	printf("\tthreads: %d\n", tasks);

	for(int i = 0; i < EXECUTIONS; i++) {

		start_time = wtime();

		mmultthread[0] = multiplicarTh(&mat_a, &mat_b, 4);
		end_time = wtime();

		printf("\tRuntime: %f\n", end_time - start_time);
		recorded_time[2] += end_time - start_time;

	}

	recorded_time[2] = recorded_time[2] / EXECUTIONS;

	sprintf(filename, "mult_multi_thread.result");
	fmat = fopen(filename,"w");
	fileout_matriz(mmultthread[0], fmat);
	fclose(fmat);
	// %%%%%%%%%%%%%%%%%%%%%%%% END %%%%%%%%%%%%%%%%%%%%%%%%

	// %%%%%%%%%%%%%%%%%%%%%%%% BEGIN %%%%%%%%%%%%%%%%%%%%%%%%
	//       Operações de Multiplicação em Bloco Multi-Threads
	mmultblocothread = (mymatriz **) malloc (sizeof(mymatriz *));
	printf("\n ##### Multiplicação em Bloco Multi-Threads de Matrizes #####\n");
	printf("\tthreads: %d\n", tasks);

	for(int i = 0; i < EXECUTIONS; i++) {

		start_time = wtime();

		mmultblocothread[0] = multiplicarThblocos(&mat_a, &mat_b, 2);

		end_time = wtime();
		//mimprimir(mmultbloco[0]);
		printf("\tRuntime: %f\n", end_time - start_time);
		recorded_time[3] += end_time - start_time;

	}

	recorded_time[3] = recorded_time[3] / EXECUTIONS;

	sprintf(filename, "mult_em_bloco_thread.result");
	fmat = fopen(filename,"w");
	fileout_matriz(mmultbloco[0], fmat);
	fclose(fmat);
	// %%%%%%%%%%%%%%%%%%%%%%%% END %%%%%%%%%%%%%%%%%%%%%%%%

	// %%%%%%%%%%%%%%%%%%%%%%%% BEGIN %%%%%%%%%%%%%%%%%%%%%%%%
	//              Comparação dos resultados
	printf("\n ##### Comparação dos Resultados da Multiplicação de Matrizes #####\n");
	printf("[Sequencial vs Em Bloco]\t");
	mcomparar (mmult[0],mmultbloco[0]);
	printf("[Sequencial vs Multi-Thread]\t");
	mcomparar (mmult[0],mmultthread[0]);
	printf("[Sequencial vs Em Bloco Multi-Thread]\t");
	mcomparar (mmult[0],mmultblocothread[0]);
	// %%%%%%%%%%%%%%%%%%%%%%%% END %%%%%%%%%%%%%%%%%%%%%%%%

	// %%%%%%%%%%%%%%%%%%%%%%%% BEGIN %%%%%%%%%%%%%%%%%%%%%%%%
	//                   Liberação de memória
	mliberar(mmult[0]);
	free (mmult[0]);
	mliberar(mmultbloco[0]);
	free (mmultbloco[0]);
	mliberar(mmultthread[0]);
	free (mmultblocothread[0]);

	mliberar(&mat_a);
	mliberar(&mat_b);
	free(mmult);
	free(mmultbloco);
	free(mmultthread);
	free(mmultblocothread);
	// %%%%%%%%%%%%%%%%%%%%%%%% END %%%%%%%%%%%%%%%%%%%%%%%%

	printf("Tempo médio execuções (10x):\n\t- Sequencial:\t%.6fs\n\t- Em Bloco:\t%.6fs\n\t- Multi-Thread:\t%.6fs\n\t- Em Bloco MultiThread:\t%.6fs\n",
		recorded_time[0], recorded_time[1], recorded_time[2], recorded_time[3]);

	printf("Speedup (Sequencial x Multithread): %.6f\n", recorded_time[0] / recorded_time[2]);
	printf("Speedup (Seq. Em Bloco x Multithr. Em Bloco): %.6f\n", recorded_time[1] / recorded_time[3]);

	return 0;
}
