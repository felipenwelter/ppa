#include "matriz-operacoesv3.h"

mymatriz *msomar (mymatriz *mat_a, mymatriz *mat_b, int tipo) {
  printf ("ERRO: Método não implementado");
  exit (1);
}

mymatriz *mmultiplicar (mymatriz *mat_a, mymatriz *mat_b, int tipo) {
  printf ("ERRO: Método não implementado");
  exit (1);
}

int multiplicar_submatriz (matriz_bloco_t *mat_suba, matriz_bloco_t *mat_subb, matriz_bloco_t *mat_subc) {
  printf ("ERRO: Método não implementado");
  exit (1);
}
