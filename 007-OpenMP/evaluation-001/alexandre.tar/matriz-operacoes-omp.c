#include "matriz-operacoes-omp.h"
#include <omp.h>
#include <stdlib.h>
#include <string.h>
#include "matrizv3.h"
#include "matriz-operacoesv3.h"


mymatriz *multiplicarOMP (mymatriz *mat_a, mymatriz *mat_b, int thread){
    omp_set_num_threads(thread);
    mymatriz *mat_resultado = malloc(sizeof(mymatriz));
    if((compararOrdem(mat_a,mat_b) == 2) || (compararOrdem(mat_a,mat_b) == 3)){ //Matriz é quadrada OU a quantidade de colunas de A é igual a quantidade de colunas de B
        mat_resultado->matriz = NULL;
        mat_resultado->lin = mat_a->lin;
        mat_resultado->col = mat_b->col;
        if (malocar(mat_resultado)) {
            printf ("ERROR: Out of memory\n");
	    }
        /*for(int i=0; i<mat_resultado->lin; ++i){
            for(int j=0; j<mat_resultado->col; ++j){
                for(int k=0; k<mat_a->col; ++k){
                    mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                }
            }
        }*/
        #pragma omp parallel for collapse(3)
        for(int i=0; i<mat_resultado->lin; ++i){
            for(int j=0; j<mat_resultado->col; ++j){
                for(int k=0; k<mat_a->col; ++k){
                    mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                }
            }
        }
        
        return (mat_resultado);
    }
    puts("Nao foi possivel realizar a operacao de multiplicacao, pois as matrizes de entrada nao eram compativeis");
    mat_resultado->matriz = NULL;
    mat_resultado->lin = 0;
    mat_resultado->col = 0;
    return (mat_resultado);
}




mymatriz *multiplicarOMPblocos(mymatriz *matrixA, mymatriz *matrixB, int id) {
    matriz_bloco_t **Vsubmat_a = NULL, **Vsubmat_b = NULL, **Vsubmat_c = NULL;

    mult_block_normal_package packages[id];
    //pthread_t threads[id];

    Vsubmat_a = particionar_matriz(matrixA->matriz, matrixA->lin, matrixA->col, 1, id);
    Vsubmat_b = particionar_matriz(matrixB->matriz, matrixB->lin, matrixB->col, 0, id);

    Vsubmat_c = csubmatrizv2(matrixA->lin, matrixB->col, id);

    mymatriz *resultado = (mymatriz *) malloc(sizeof(mymatriz));

    resultado->lin = matrixA->lin;
    resultado->col = matrixB->col;

    malocar(resultado);
    mzerar(resultado);

    omp_set_num_threads(id);
    #pragma omp parallel
    {
    /*for (int i = 0; i < id; i++) {
        packages[i].inicio = Vsubmat_a[i];
        packages[i].fim = Vsubmat_b[i];
        packages[i].resultado = Vsubmat_c[i];

        pthread_create(&threads[i], NULL, mult_block_thread_job, (void *) (packages + i));
    }*/
    packages[omp_get_thread_num()].inicio = Vsubmat_a[omp_get_thread_num()];
    packages[omp_get_thread_num()].fim = Vsubmat_b[omp_get_thread_num()];
    packages[omp_get_thread_num()].resultado = Vsubmat_c[omp_get_thread_num()];

    mult_block_thread_job(packages + omp_get_thread_num());

    }

    for (int i = 0; i < id; i++) {
        //pthread_join(threads[i], NULL);
        mymatriz *temp = msomar(resultado, Vsubmat_c[i]->matriz, 0);
        resultado = temp;
    }

    return resultado;
}


void *mult_block_thread_job(void *dado) {
    mult_block_normal_package *matriz = (mult_block_normal_package *) dado;
    mmsubmatriz(matriz->inicio, matriz->fim, matriz->resultado);
    return NULL;
}
